"use client";
import React from "react";
import "./index.css"
const Loader = ({ children }) => {
    return (
        <>
            <div class="loader"></div>

        </>
    );
};

export default Loader;
