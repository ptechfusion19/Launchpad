// import Cors from 'cors';
// import { initMiddleware } from './init-middleware';

// // Initialize the CORS middleware with the settings
// const cors = initMiddleware(
//     Cors({
//         methods: ['GET', 'POST', 'OPTIONS'],
//         origin: 'https://www.bundlebee.tech', // Replace with your frontend domain
//         allowedHeaders: ['Content-Type', 'Authorization'],
//     })
// );

// export default cors;
