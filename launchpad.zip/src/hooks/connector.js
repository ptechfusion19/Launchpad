// import { initializeConnector } from '@web3-react/core';
// import { Phantom } from 'web3-react-phantom';

// const phantom = initializeConnector((actions) => new Phantom({ actions }));

// const connectors = [phantom];

// export default connectors;