import { createContext } from "react";


const LaunchPadContext = createContext();


export default LaunchPadContext;